<template>
    <div>
        <div><slot name="title"></slot>
            <span style="color:blue"><slot name="subtitle">The Subtitle</slot></span>
        </div>
        <div><slot name="content"></slot></div>
    </div>
</template>

<script></script>

<style scoped>
div{
    border:1px solid grey;
    box-shadow:1px 1px 2px black;
    padding:30px;
    margin :30px auto;
    text-align:center;
}
h2{
    color:red;
}
</style>