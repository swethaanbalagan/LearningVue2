<template>
    <div class="container">
        <div class="row">
            <div class="col-xs-12 col-sm-8 col-sm-offset-2 col-md-6 col-md-offset-3">
                <h1>Filters & Mixins</h1>
                <p>{{ text| upperCase }}</p>
                <p>{{ text| lowerCase }}</p>
                <input type="textarea" v-model="filterText">
                <ul>
                    <li v-for="fruit in filteredFruits" :key="fruit">{{ fruit }}</li>
                </ul>
            </div>
        </div>
        <app-list></app-list>
    </div>
</template>

<script>
import LisT from '@/components/LisT.vue';
import {fruitMixin} from './fruitMixin.js'
    export default {
        //mixins:['fruitMixin'],
        mixins:[fruitMixin],
        components:{
            'app-list':LisT
        },
        data(){
            return{
                'text':'Hello There!',
            }
        },
        filters:{
            upperCase(value){
                return value.toUpperCase();
            }
        },
        created(){
            console.log('created from App instance')
        }
    }
</script>

<style>

</style>
