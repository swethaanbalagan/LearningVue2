<template>
  <div>
    <button
      class="btn btn-primary"
      @click="asynincrement({ by: 100, duration: 1000 })"
    >
      Increment
    </button>
    <button
      class="btn btn-primary"
      @click="asyndecrement({ by: 50, duration: 1000 })"
    >
      Decrement
    </button>
  </div>
</template>

<script>
import { mapActions } from "vuex";
export default {
  methods: {
    ...mapActions(["asynincrement", "asyndecrement"]),
  },
};
</script>
