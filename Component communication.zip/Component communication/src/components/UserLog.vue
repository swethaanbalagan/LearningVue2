<template>
    <div class="component">
        <h1>The User Component</h1>
        <p>I'm an awesome User!</p>
        <button @click="changeName">Change My Name</button>
        <p>My name is {{ name }}</p>
        <p>My age is :{{ age }}</p>
        <hr>
        <div class="row">
            <div class="col-xs-12 col-sm-6">
                <app-user-detail :name="name" 
                                :resetFn="resetname"
                                :age="age"
                                @name-reset="name=$event"></app-user-detail>
            </div>
            <div class="col-xs-12 col-sm-6">
                <app-user-edit :age="age"
                                :resetaFn="resetage"></app-user-edit>
            </div>
        </div>
    </div>
</template>

<script>
    import UserDetail from './UserDetail.vue';
    import UserEdit from './UserEdit.vue';

    export default {
        data(){
            return{
                name:'Mark',
                age:27
            }
        },
        methods:{
            changeName(){
                this.name='Anna'
            },
            resetname(){
                this.name='Mark'
            },
            resetage(){
                this.age=30
            }
        },
        components: {
            appUserDetail: UserDetail,
            appUserEdit: UserEdit
        }
    }
</script>

<style scoped>
    div {
        background-color: lightblue;
    }
</style>
