<template>
  <div id="app">
    <h1>Routing</h1>
    <router-view name="header-top" />
    <router-view />
    <router-view name="header-bottom" />
  </div>
</template>

<script>
// import HeaderF from "@/components/HeaderF.vue";

// export default {
//   components: {
//     "app-header": HeaderF,
//   },
// };
</script>

<style>
#app {
  font-family: Avenir, Helvetica, Arial, sans-serif;
  -webkit-font-smoothing: antialiased;
  -moz-osx-font-smoothing: grayscale;
  text-align: center;
  color: #2c3e50;
}

nav {
  padding: 30px;
}

nav a {
  font-weight: bold;
  color: #2c3e50;
}

nav a.router-link-exact-active {
  color: #42b983;
}
</style>
