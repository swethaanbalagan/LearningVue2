<template>
    <div><h3>New Quote</h3>
    </div>
</template>

<script>
export default{
    destroyed(){
        alert('destroyed')
    },
    deactivated(){
        console.log('deactivated')
    },
    activated(){
        console.log('activated')
    }
}
</script>

<style scoped>
</style>