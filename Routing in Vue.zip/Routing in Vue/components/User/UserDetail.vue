<template>
  <div>
    <h2>User Detail</h2>
    <p>User Log:{{ $route.params.id }}</p>
    <!-- <router-link
      custom
      v-slot="{ navigate }"
      :to="'/user/' + $route.param.id + '/edit'"
    >q
      <button @click="navigate">Det</button>
    </router-link> -->

    <!-- <router-link :to="'/user/' + $route.params.id + '/edit'"> -->

    <router-link
      :to="{
        name: 'userEdit',
        params: { id: $route.params.id },
        query: { locale: 'en', q: 100 },
        hash: '#datam',
      }"
    >
      <button>Edit</button>
    </router-link>
  </div>
</template>
