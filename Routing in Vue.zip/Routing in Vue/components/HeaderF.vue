<template>
  <nav>
    <router-link to="/">Home</router-link> |
    <router-link to="/user">User</router-link>
  </nav>
</template>
