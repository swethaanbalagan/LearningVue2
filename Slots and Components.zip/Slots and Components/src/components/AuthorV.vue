<template>
    <div><h3>The Author</h3>
    </div>
</template>

<script></script>

<style scoped>
</style>