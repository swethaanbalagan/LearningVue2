<template>
    <div class="container">
        <div class="row">
            <div class="col-xs-12 col-sm-8 col-sm-offset-2 col-md-6 col-md-offset-3">
                <h1>Built-in Directives</h1>
                <p v-text="'Some text'"></p>
                <p v-html="'<strong>Strong Text</strong>'"></p>
            </div>
        </div>
        <hr>
        <div class="row">
            <div class="col-xs-12 col-sm-8 col-sm-offset-2 col-md-6 col-md-offset-3">
                <h1>Custom Directives</h1>
                <p v-highlight:background.delay="'red'">Color this!</p>
                <p v-local-highlight:background.delayed.blink="{delay:500, mainColor:'red',secondaryColor:'green'}">{{ text }}</p>
            </div>
        </div>
        <hr>
        <div
            v-decorate="{
                margin: '24px',
                borderRadius: '4px',
                backgroundColor: 'teal',
            }">
        </div>
    </div>
</template>


<script>
    export default {
        data(){
            return{text:'Hi Hello Little Beggar Boy'}
        },
        directives:{
            'local-highlight':{
                bind(el,binding,vnode){
                //el.style.backgroundColor='green';
                var delay=0;
                if(binding.modifiers['delayed']){
                delay=binding.value.delay;
                }
                
                if(binding.modifiers['blink']){
                    var mainColor=binding.value.mainColor;
                    var secondaryColor=binding.value.secondaryColor;
                    var currentColor=mainColor;
                    setTimeout(()=>{
                        setInterval(
                        ()=>{
                            currentColor===mainColor?currentColor=secondaryColor:currentColor=mainColor;
                            if(binding.arg=='background')
                            el.style.backgroundColor=currentColor;
                            else
                            el.style.color=currentColor;
                            },binding.value.delay);
                    },delay);
                    
                }
                else{
                    setTimeout(()=>{
                    if(binding.arg=='background')
                    el.style.backgroundColor=binding.value;
                    else
                    el.style.color=binding.value;
                    },delay);
                }
            }
        }
    }
}
</script>

<style>

</style>
