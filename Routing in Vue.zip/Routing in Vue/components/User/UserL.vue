<template>
  <div>
    <h2>the User Page</h2>
    <hr />
    <!-- <p>Loaded ID: {{ id }}</p> -->
    <button @click="navigateToHome">Go to Home</button>
    <hr />
    <router-view></router-view>
  </div>
</template>

<script>
//import UserStart from "@/components/User/UserStart.vue";
export default {
  // components: {
  //   "user-start": UserStart,
  // },
  // data() {
  //   return {
  //     id: this.$route.params.id,
  //   };
  // },
  // watch: {
  //   $route(to) {
  //     this.id = to.params.id;
  //   },
  // },
  methods: {
    navigateToHome() {
      this.$router.push({ path: "/" });
    },
  },
};
</script>
