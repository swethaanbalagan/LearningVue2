<template>
    <div class="container">
        <button @click="selectedComp='app-quote'">Qoute</button>
        <button @click="selectedComp='app-author'">Author</button>
        <button @click="selectedComp='app-new'">New</button>
        <div class="row">
            <div class="col-xs-12">
                <keep-alive>
                    <component :is="selectedComp">

</component>
                </keep-alive>
            </div>
        </div>
    </div>
</template>

<script>
import QuoteLog from '@/components/QuoteLog.vue';
import AuthorV from '@/components/AuthorV.vue';
import NewV from '@/components/NewV.vue';
    export default {
        components:{
            'app-quote': QuoteLog,
            'app-author': AuthorV,
            'app-new': NewV
        },
        data(){
            return{
                selectedComp:'app-quote'
            }
        }
    }
</script>

<style>
</style>
