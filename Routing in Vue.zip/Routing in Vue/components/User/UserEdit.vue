<template>
  <div>
    <h2>User Edit</h2>
    <p>Locale:{{ locale }}</p>
    <p>Analytics:{{ q }}</p>
    <div style="height: 700px"></div>
    <router-link to="/">
      <button @click="confirmed = true">Submit</button>
    </router-link>
    <p id="datam">datatatata</p>
  </div>
</template>

<script>
export default {
  data() {
    return {
      locale: this.$route.query.locale,
      q: this.$route.query.q,
      confirmed: false,
    };
  },
  watch: {
    $route(to) {
      (this.locale = to.query.locale), (this.q = to.query.q);
    },
  },
  beforeLeave(to, from, next) {
    if (this.confirmed === true) {
      next();
    } else {
      if (confirm("Are You Sure?")) {
        next();
      } else {
        next(false);
      }
    }
  },
};
</script>
