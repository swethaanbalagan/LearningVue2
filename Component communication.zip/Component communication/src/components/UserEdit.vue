<template>
    <div class="component">
        <h3>You may edit the User here</h3>
        <p>Edit me!</p>
        <p>Age is :{{ age }}</p>
        <button @click="resetaFn">Reset Age(Reflect in sibling via parent)</button>
        <button @click="resetage">Reset Age(Reflect in sibling only)</button>
    </div>
</template>

<script>
import {eventBus} from '../main'
export default{
    props:{
        age:Number,
        resetaFn:Function
    },
    methods:{
        resetage(){
            this.age=40;
            eventBus.$emit('agereset',this.age)
        }
    }
}
</script>

<style scoped>
    div {
        background-color: lightgreen;
    }
</style>
