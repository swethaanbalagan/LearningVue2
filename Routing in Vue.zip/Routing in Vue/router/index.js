import Vue from "vue";
import VueRouter from "vue-router";
import HomeView from "../views/HomeView.vue";
import UserL from "@/components/User/UserL.vue";
import UserStart from "@/components/User/UserStart.vue";
import UserEdit from "@/components/User/UserEdit.vue";
import UserDetail from "@/components/User/UserDetail.vue";
import HeaderF from "@/components/HeaderF.vue";

Vue.use(VueRouter);

const routes = [
  {
    path: "/",
    name: "home",
    components: {
      default: HomeView,
      "header-top": HeaderF,
    },
  },
  {
    path: "/about/:id",
    name: "about",
    // route level code-splitting
    // this generates a separate chunk (about.[hash].js) for this route
    // which is lazy-loaded when the route is visited.
    component: () =>
      import(/* webpackChunkName: "about" */ "../views/AboutView.vue"),
  },

  {
    path: "/user",
    component: UserL,
    components: {
      default: UserL,
      "header-bottom": HomeView,
    },
    children: [
      { path: "/", component: UserStart },
      { path: "/user/:id", component: UserDetail },
      { path: ":id/edit", component: UserEdit, name: "userEdit" },
    ],
  },
  {
    path: "/redirect-me",
    redirect: "/user",
  },
  {
    path: "*",
    redirect: "/",
  },
];

const router = new VueRouter({
  mode: "history",
  base: process.env.BASE_URL,
  routes,
  scrollBehaviour(to, savedPosition) {
    if (to.hash) {
      console.log("datamm");
      return { el: to.hash, behavior: "smooth" };
    }
    return savedPosition;
  },
});

export default router;
