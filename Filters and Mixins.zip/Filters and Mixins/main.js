import Vue from 'vue'
import App from './App.vue'

Vue.filter('lowerCase',(value)=>{
  return value.toLowerCase();
})
Vue.mixin({
  created(){
    console.log('Created Hook from Global Mixin')
  }
})

new Vue({
  el: '#app',
  render: h => h(App)
})
