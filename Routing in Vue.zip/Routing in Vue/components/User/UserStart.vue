<template>
  <div>
    <p>Please select a User</p>
    <ul>
      <router-link to="/user/1">User 1</router-link>
      |
      <router-link to="/user/2">User 2</router-link>
      |
      <router-link to="/user/3">User 3</router-link>
      |
    </ul>
  </div>
</template>

<!-- <router-link to="/user/1" custom v-slot="{ navigate }">
      <li @click="navigate" role="link">User 1</li>
    </router-link> -->
<!-- <router-link tag="li" to="/user/2">User 2</router-link> -->
