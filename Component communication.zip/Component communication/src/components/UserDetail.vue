<template>
    <div class="component">
        <h3>You may view the User Details here</h3>
        <p>Many Details</p>
        <p>User name:{{ changeNamee() }}</p>
        <button @click="resetname">Reset Name (emit event)</button>
        <button @click="resetFn"> Reset Name(callback from Parent)</button>
        <p>Age is :{{ age }}</p>
    </div>
</template>

<script>
import {eventBus} from '../main'
export default{
    props:{
        'name':{
            type:String,
            required:true
        },
        resetFn:Function,
        age: Number
    },
    methods:{
        changeNamee(){
            return this.name.split("").reverse().join("");
        },
        resetname(){
            this.$emit('name-reset','Millie')
        }
    },
    created(){
        eventBus.$on('agereset',(data)=>{this.age=data;})
    }
}
</script>

<style scoped>
    div {
        background-color: lightcoral;
    }
</style>
